<?php
include 'php/session.php';
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <title>Bootstrap Form</title>
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/app.css">
</head>
<body class="bg-light">
<!--navigation-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="collapse navbar-collapse">
<ul class="navbar-nav mr-auto">
  <li class="nav-item">
	<a class="nav-link" href="index.php">Home</a>
  </li>
  <li class="nav-item">
	<a class="nav-link"  href="admin.php">Admin</a>
  </li>
</ul>
</div>
  <form class="form-inline" method="post" action="php/session.php">
    <button class="btn btn-outline-danger my-2 my-sm-0" type="submit" name="logout" >Logout</button>
  </form>
</nav>
<!--/navigation-->
<div class="container">
<div class="row">
<div class="col-xs-12">
<h1>Job Applications of X Company</h1>
<?php 
if(count($session_data)){
	if($session_data['is_admin'] == 0){
		$dbo->print_errors($errors=['Admin Area']);
		exit;
	}
?>
<!-- Modal -->
<div class="modal fade" id="modal-default" tabindex="-1" role="dialog" aria-labelledby="modalTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalTitle">Applicant Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="modal_body">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--/Modal -->

<table class="table">
  <thead>
    <tr>
      <th scope="col">username</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Email address</th>
	  <th scope="col">Phone</th>
	  <th scope="col">Details</th>
    </tr>
  </thead>
  <tbody>
  <?php $rows = $dbo->rows('users');
  while($row = array_shift($rows)){ ?>
    <tr>
      <td><?= $row['username'] ?></td>
      <td><?= $row['first_name'] ?></td>
      <td><?= $row['last_name'] ?></td>
      <td><?= $row['email'] ?></td>
	  <td><?= $row['phone'] ?></td>
	  <td><a href="#" onclick=showApplicantDetails('<?= $row['id'] ?>');  data-toggle="modal" data-target="#modal-default">Details</a></td>
    </tr>
  <?php } ?>
  </tbody>
</table>

<?php
}else{
	$dbo->print_messages($messages=['<a href="signin.php"><h4>Please Sign In</h4><a>']);
}
?>

</div>
</div>
</div>
<!-- Bootstrap core JavaScript -->
  <script src="jquery/jquery-3.4.1.min.js"></script>
  <script src="bootstrap/js/bootstrap.js"></script>
  <script type="text/javascript" src="jquery-validation/dist/jquery.validate.js"></script>
  <script>
   function showApplicantDetails(applicant_id) {
    let post_value = {applicant_id: applicant_id};
    $.ajax({
        url: "php/showapplicantdetails.php",
        data: post_value,
        method: "POST",
        success: function(result) {
            $("#modal_body").html(result);
        }
    });
	}
    </script>
</body>
</html>