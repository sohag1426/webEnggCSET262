<?php
	//from base class
	//dbms
	$dbo->query_builder($query_argument = array());
	$dbo->build_query($table,$command,$columns=[],$where='');
	$dbo->run_query($query_string, $values_agrument = array());
	$dbo->get_table_info($table);
	$dbo->get_column_names($table='');
	$dbo->array_to_and_filter($table, $post_data=[]);
	$dbo->rows($table='', $filter_string='', $filter_value=[]);
	$dbo->row($table='', $filter_string='', $filter_value=[]);
	$dbo->sort_rows($rows=[], $sorted_column='', $asc=1);
	$dbo->count_row($table='', $filter_string='', $filter_value=[]);
	$dbo->sum_col($column='', $table='', $filter_string='', $filter_value=[]);
	$dbo->select($query,$placeholders_values=[]);
	$dbo->insert($table='', $post_data=[], $session_data=[], $log=true);
	$dbo->update($table='', $post_data=[], $filter_string='', $filter_value=[], $session_data=[], $log=true);
	$dbo->delete_row($table='', $filter_string='', $filter_value=[], $session_data=[], $log=true);
	$dbo->truncate($table);
	$dbo->run_sql_command($command,$placeholders_values=[]);
	$dbo->get_tables($attribute='');
	
	
	//cache related
	$dbo->cache_stats();
	$dbo->add_to_memcache($cache_key,$data);
	$dbo->delete_from_memcache($cache_key);
	$dbo->get_from_memcache($cache_key);
	$dbo->cache_rows($table='', $filter_string='', $filter_value=[], $sort=0, $sorted_column='', $asc=1);
	$dbo->get_cached_rows($table='', $filter_string='', $filter_value=[], $sort=0, $sorted_column='', $asc=1);
	$dbo->update_cached_row($table='', $update_key, $updated_row=[]);
	$dbo->purge_cached_rows($table);

	//not dbms
	$dbo->print_errors($errors=[]);
	$dbo->print_message($message='', $require_close = 0);
	$dbo->print_messages($messages=[]);
	$dbo->redirect($url);
	$dbo->randomPassword();
	$dbo->encrypt_decrypt($action, $value);
	$dbo->validate_mobile($mobile_number);
	$dbo->get_var_name($string);
	$dbo->remove_illegal_char($string);
	$dbo->is_mobile();
	$dbo->upload_file($file=array(), $prefix, $file_type=array(), $file_size='512K', $user_id, $image_x=150, $resize=true);
	$dbo->seconds_to_hour_minute_second($seconds);
	$dbo->get_start_and_stop_time_of_last_month();
	$dbo->previous_month();
	$dbo->this_month();
	$dbo->logoMini($session_data=[]);
	$dbo->logoLg($session_data=[]);
	
	