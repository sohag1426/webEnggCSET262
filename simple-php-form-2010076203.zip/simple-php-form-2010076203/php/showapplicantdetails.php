<?php
if($_SERVER["REQUEST_METHOD"] == "POST") {
include 'session.php';
$row = $dbo->row('users','WHERE id=:id',[":id" => $_POST['applicant_id']]);
?>
<ul class="list-group">
  <li class="list-group-item"><b>username: </b> <?= $row['username'] ?> </li>
  <li class="list-group-item"><b>Name: </b> <?= $row['first_name'] . ' ' . $row['last_name'] ?></li>
  <li class="list-group-item"><b>Email address: </b> <?= $row['email'] ?> </li>
  <li class="list-group-item"><b>Phone: </b> <?= $row['phone'] ?> </li>
  <li class="list-group-item"><b>Web Site: </b> <?= $row['web_site'] ?> </li>
  <li class="list-group-item"><b>Date of Birth: </b> <?= $row['date_of_birth'] ?> </li>
  <li class="list-group-item"><b>Address: </b> <?= '<br>' . $row['street_address'] . '<br>' . $row['address_line_2'] . '<br>' . $row['city'] . ',' . $row['state'] . '-' . $row['postal'] . '<br>' . $row['country'] ?> </li>
  <li class="list-group-item"><b>Sex: </b> <?= $row['sex'] ?> </li>
  <li class="list-group-item"><b>Bio: </b> <?= $row['bio'] ?> </li>
  <li class="list-group-item"><b>Division of Interest: </b><br> 
  <?php
	$interests = json_decode($row['division_of_interest'], true);
	foreach ($interests as $i){
		echo $i . '<br>';
	}
  ?>
  </li>
  <li class="list-group-item"><b>Expected Salary: </b> <?= $row['salary'] . ' TK' ?> </li>
  <li class="list-group-item"><b>Latest Degree: </b> <?= $row['latest_degree'] ?> </li>
  <li class="list-group-item"><b>Year(s) of Experience: </b> <?= $row['experience'] . ' Year' ?> </li>
  <li class="list-group-item"><b>Name of Current Designation: </b> <?= $row['designation'] ?> </li>
  <li class="list-group-item"><b>CV: </b>
  <?php if(strlen($row['cv'])) { ?>
   <a href="<?php echo 'uploads/'. $row['cv']; ?>">Download</a>
  <?php } ?>
  </li>
</ul>
<?php } ?>
