<?php
include 'constants.php';
include 'class.app.db.config.php';
include 'class.base.php';
$dbo = new base();
$session_data = [];

if (!isset($_SESSION)) {
    session_start();
}

/*logout_*/
if($_SERVER["REQUEST_METHOD"] == "POST") {
	if(isset($_POST['logout'])){
		unset($_SESSION);
		session_destroy();
		header('location: ../index.php');
	}
}
/*_logout*/

if(isset($_SESSION['session_data'])){
	$session_data = $dbo->encrypt_decrypt('decrypt', $_SESSION['session_data']);
}
?>
