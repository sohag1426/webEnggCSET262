<?php
/**
 * Version: 1.2
 * Last UPDATE: 15-Sep-2019
 * DESIGNED FOR INSERT, SELECT, UPDATE, DELETE DBMS Operations and other core functions.
 * DESIGNED BY MD. SOHAG HOSEN
 * sohag1426@gmail.com
 */
 
class base  {
	
	######### 		  DBMS Start Here 			#####
	
	
	/**
	 * @database config
	 * @access protected
	 */
	protected $ndb_host = null;
	protected $ndb_name = null;
	protected $ndb_user = null;
	protected $ndb_pass = null;
	protected $ndb_port = null;
	protected $ndb_char = 'utf8';
	public $mypdo = null;
	
	
	
	
	
	/**
	 * information_schema database config
	 * @access protected
	 */
	protected $infodb_host = null;
	protected $infodb_name = null;
	protected $infodb_user = null;
	protected $infodb_pass = null;
	protected $infodb_port = null;
	protected $infodb_char = 'utf8';
	public $infopdo = null;
	
	
	
	
	
	/**
	 * get database parameters from config file
	 * @access protected
	 * @return void
	 */
	protected function set_db_params() {
		$this->ndb_host = app_db_config::app_db_host;
		$this->ndb_name = app_db_config::app_db_name;
		$this->ndb_user = app_db_config::app_db_user;
		$this->ndb_pass = app_db_config::app_db_pass;
		$this->ndb_port = app_db_config::app_db_port;
	}

	
	
	
	
	
	/**
	 * get information_schema database parameters from config file
	 * @access protected
	 * @return void
	 */
	protected function set_infodb_params() {
		$this->infodb_host = app_db_config::app_db_host;
		$this->infodb_name = 'information_schema';
		$this->infodb_user = app_db_config::app_db_user;
		$this->infodb_pass = app_db_config::app_db_pass;
		$this->infodb_port = app_db_config::app_db_port;
	}





	/**
	 * Connect to the database and SET mypdo
	 * Call when $this->mypdo == null
	 * @access protected
	 * @mypdo
	 */
	protected function ndb_connect() {
		$this->set_db_params();
		$dsn = 'mysql:host=' . $this->ndb_host . ';dbname=' . $this->ndb_name . ';port='. $this->ndb_port . ';charset=' . $this->ndb_char;
		$opt = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false, PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => true);
		$this->mypdo = new PDO($dsn, $this->ndb_user, $this->ndb_pass, $opt);
	}
	
	
	
	
	
	
	/**
	 * Connect to the information_schema database and SET infopdo
	 * Call when $this->infopdo == null
	 * @access protected
	 * @infopdo
	 */
	protected function infodb_connect() {
		$this->set_infodb_params();
		$dsn = 'mysql:host=' . $this->infodb_host . ';dbname=' . $this->infodb_name . ';port='. $this->infodb_port . ';charset=' . $this->infodb_char;
		$opt = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false, PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => true);
		$this->infopdo = new PDO($dsn, $this->infodb_user, $this->infodb_pass, $opt);
	}

	
	
	
	
	
	/**
	 * Are we currently connected to the database
	 * @access public
	 * @return void
	 */
	public function is_connected() {
		return $this->mypdo !== null;
	}


	
	
	/**
	 * Are we currently connected to the information_schema database
	 * @access public
	 * @return void
	 */
	public function is_infodb_connected() {
		return $this->infopdo !== null;
	}




	/**
	 * Get Database connection.
	 * @access public
	 * @set mypdo
	 */
	public function get_connection() {
		if (!$this->is_connected()) $this->ndb_connect();
	}

	
	
	
	/**
	 * Get information_schema Database connection.
	 * @access public
	 * @set mypdo
	 */
	public function get_infodb_connection() {
		if (!$this->is_infodb_connected()) $this->infodb_connect();
	}

	
	
	
	
	/**
	 * Get Query String.
	 * @access public
	 * @Input array contains either string or Indexed array.
	 * @param array $query_argument (optional)
	 * @return mixed
	 */
	public function query_builder($query_argument = array()) {
		$command = strtoupper(trim($query_argument['command']));
		$select = implode(', ', $query_argument['select']);
		$table = $query_argument['table'];
		$set_array = $query_argument['set_array'];
		$filter_string = $query_argument['filter_string'];
		if (substr(strtoupper(trim($filter_string)), 0, 5) != 'WHERE') {
			$filter_string = 'WHERE '.$filter_string;
		}
		if ($command == 'INSERT' || $command == 'UPDATE') {
			$set_string = implode(', ', $set_array);
		}
		if ($command == 'INSERT') {
			$query = $command . ' INTO ' . $table . ' SET ' . $set_string;
		}
		if ($command == 'SELECT') {
			if ($filter_string == '') {
				$query = $command . ' ' . $select . ' FROM ' . $table;
			} else {
				$query = $command . ' ' . $select . ' FROM ' . $table . ' ' . $filter_string;
			}
		}
		if ($command == 'UPDATE') {
			$query = $command . ' ' . $table . ' SET ' . $set_string . ' ' . $filter_string;
		}
		if ($command == 'DELETE') {
			$query = $command . ' FROM ' . $table . ' ' . $filter_string;
		}
		return $query;
	}
	
	
	
	
	/**
	 * Get Query String.
	 * @access public
	 * @param string $table
	 * @param string $command
	 * @param indexed array $columns
	 * @param string $where
	 * @return mixed
	 */
	public function build_query($table,$command,$columns=[],$where='') {
		//command
		$command=strtoupper(trim($command));
		//filter_string
		if (substr(strtoupper(trim($where)), 0, 5) != 'WHERE') {
			$filter_string = 'WHERE '.$where;
		}
		//set string
		if ($command == 'INSERT' || $command == 'UPDATE') {
			foreach ($columns as $column) {
				$set_array[]=$column.'=:'.$column;
			}
			$set_string = implode(', ', $set_array);
		}
		//insert query
		if ($command == 'INSERT') {
			$query = $command . ' INTO ' . $table . ' SET ' . $set_string;
		}
		//select query
		if ($command == 'SELECT') {
			$select = implode(', ', $columns);
			if (strlen($where)) {
				$query = $command . ' ' . $select . ' FROM ' . $table . ' ' . $filter_string;
			} else {
				$query = $command . ' ' . $select . ' FROM ' . $table;
			}
		}
		//update query
		if ($command == 'UPDATE') {
			$query = $command . ' ' . $table . ' SET ' . $set_string . ' ' . $filter_string;
		}
		//delete query
		if ($command == 'DELETE') {
			$query = $command . ' FROM ' . $table . ' ' . $filter_string;
		}
		
		return $query;
	}
	
	
	
	
	/**
	 * Run Query.
	 * @access public
	 * @values are associate array.
	 * @param string $query_string
	 * @param array $values_agrument (optional)
	 * @return mixed
	 */
	public function run_query($query_string, $values_agrument = array()) {
		$command = $values_agrument['command'];
		$set_values = $values_agrument['set_values'];
		$filter_values = $values_agrument['filter_values'];
		if ($command == 'INSERT') {
			$values = $set_values;
		}
		if ($command == 'UPDATE') {
			$values = array_merge($set_values, $filter_values);
		}
		if ($command == 'SELECT' || $command == 'DELETE') {
			$values = $filter_values;
		}
		$this->get_connection();
		//prepare
		$sql_statement = $this->mypdo->prepare($query_string);
		if (is_object($sql_statement)) {
			//bindValue
			if (count($values) > 0) {
				foreach ($values as $k => $v) {
					if (!strlen($v)) {
						$sql_statement->bindValue($k, $v, PDO::PARAM_NULL);
					}else {
						$sql_statement->bindValue($k, $v);
					}
				}
			}
			//execute
			$result = $sql_statement->execute();
			if ($command=='INSERT') {
				$result=$this->last_insert_id();
			}
			if ($command == 'SELECT') {
				$result = $sql_statement->fetchAll();
			}
			if ($command=='DELETE' || $command=='UPDATE') {
				$result=$sql_statement->rowCount();
			}
		}
		return $result;
	}



	/**
	 * Returns last insert ID
	 * @access public
	 * @return int
	 */
	public function last_insert_id() {
		return $this->mypdo->lastInsertId();
	}



	/**
	 * Returns values String
	 * @access public
	 * @param array $values_agrument (optional)
	 * @return string
	 */
	public function values_string($values_agrument = array()) {
		$command = $values_agrument['command'];
		$set_values = $values_agrument['set_values'];
		$filter_values = $values_agrument['filter_values'];
		if ($command == 'INSERT') {
			$values = $set_values;
		}
		if ($command == 'UPDATE') {
			$values = array_merge($set_values, $filter_values);
		}
		if ($command == 'SELECT' || $command == 'DELETE') {
			$values = $filter_values;
		}
		if (count($values) > 0) {
			foreach ($values as $k => $v) {
				$ind_values[] = $k . '=' . $v;
				$values_string = implode(', ', $ind_values);
			}
		} else {
			$values_string = '';
		}
		return $values_string;
	}

	
	
	
	
	/**
	 * get information of a table
	 * @access public
	 * @param string $table
	 * @return array
	 */
	public function get_table_info($table) {
		if (strlen($table)) {
			//get table_schema
			$this->set_db_params();
			$table_schema=$this->ndb_name;
			//get query_string
			$command='SELECT';
			$query_argument = [
				'command'     => $command,
				'select'      => ['COLUMN_NAME', 'IS_NULLABLE', 'DATA_TYPE', 'CHARACTER_MAXIMUM_LENGTH', 'COLUMN_COMMENT', 'COLUMN_DEFAULT'],
				'table'        => 'COLUMNS',
				'set_array'    => [],
				'filter_string' => 'WHERE TABLE_SCHEMA=:TABLE_SCHEMA AND TABLE_NAME=:TABLE_NAME'
			];
			$query_string = $this->query_builder($query_argument);
			//get get_infodb_connection
			$this->get_infodb_connection();
			$statement=$this->infopdo->prepare($query_string);
			$filter_value=[":TABLE_SCHEMA" => $table_schema, ":TABLE_NAME" => $table];
			$statement->execute((array)$filter_value);
			$rows=$statement->fetchAll();
			$info=[];
			while ($row=array_shift($rows)) {
				if ($row['COLUMN_NAME'] != 'id') {
					$data = [];
					$data = ["is_nullable" => $row['IS_NULLABLE'], "data_type" => $row['DATA_TYPE'], "max_length" => $row['CHARACTER_MAXIMUM_LENGTH'], "comment" => $row['COLUMN_COMMENT'], "default_value" => $row['COLUMN_DEFAULT']];
					$info[$row['COLUMN_NAME']]=$data;
				}
			}
			return $info;
		}else {
			return false;
		}
	}
	
	
	
	
	/**
	 * get column names of a table
	 * @access public
	 * @param string $table (optional)
	 * @return array
	 */
	public function get_column_names($table='') {
		if (strlen($table)) {
			$info = $this->get_table_info($table);
			return array_keys($info);
		}else {
			return false;
		}
	}
	
	
	
	
	
	/**
	 * activities_log
	 * @access public
	 * @param string $log_values (optional)
	 * @return void
	 */
	public function operational_log($log_values=array()) {
		$this->get_connection();
		$log_insert=$this->mypdo->prepare('INSERT INTO `activities_log` SET filename=:filename, command=:command, query_string=:query_string, values_string=:values_string, creator_id=:creator_id, creation_by=:creation_by')->execute((array)$log_values);
	}
	
	
	
	/**
	 * resets connection.
	 * @access public
	 * @return void
	 */
	public function reset_conn() {
		$this->mypdo=null;
	}

	
	
	
	/**
	 * reset infodb connection.
	 * @access public
	 * @return void
	 */
	public function reset_infodb_conn() {
		$this->infopdo=null;
	}
	
	
	/**
	 * @param string $table
	 * @param array $post_data (optional)
	 * @return string
	 */
	public function array_to_and_filter($table, $post_data=[]) {
		$filter=[];
		$filter_string='';
		$filter_value=[];
		if (count($post_data)) {
			//get table columns
			$fields=$this->get_column_names($table);
			//unset empty and garbage
			foreach ($post_data as $key => $value) {
				if (in_array($key, $fields)) {
					if (strlen($value)==false) {
						unset ($post_data[$key]);
					}
				}else {
					unset ($post_data[$key]);
				}
			}
			// form array
			$filter_string_array=[];
			$filter_value=[];
			foreach ($post_data as $key => $value) {
				$filter_string_array[]=$key.'=:filter_'.$key;
				$filter_value[':filter_'.$key]=$post_data[$key];
			}
			//from string
			if (count($filter_value)) {
				$filter_string='WHERE ';
				$i=count($filter_string_array);
				for ($j=0; $j<$i; $j++) {
					$filter_string.= $filter_string_array[$j];
					if ($j<($i-1)) {
						$filter_string.= ' AND ';
					}
				}
			}
		}
		//return
		$filter['string']=$filter_string;
		$filter['value']=$filter_value;
		return $filter;
	}


	
	/**
	 * @access public
	 * @param string $table         (optional)
	 * @param string $filter_string (optional)
	 * @param array $filter_value  (optional)
	 * @return two dimensional array
	 */
	public function rows($table='', $filter_string='', $filter_value=[]) {
		if (strlen($filter_string)) {
			$query_string='SELECT * FROM `'. $table . '` ' . $filter_string;
		}else {
			$query_string='SELECT * FROM `'. $table . '`';
		}
		$this->get_connection();
		$statement=$this->mypdo->prepare($query_string);
		if (sizeof($filter_value) > 0) {
			$statement->execute((array)$filter_value);
		}else {
			$statement->execute();
		}
		return $statement->fetchAll();
	}
	
	
	
	
	/**
	 * @access public
	 * Return False if no data
	 * @param string $table         (optional)
	 * @param string $filter_string (optional)
	 * @param string $filter_value  (optional)
	 * @return one dimensional array
	 */
	public function row($table='', $filter_string='', $filter_value=[]) {
		$query_string='SELECT * FROM `'. $table . '` ' . $filter_string;
		$this->get_connection();
		$statement=$this->mypdo->prepare($query_string);
		$statement->execute((array)$filter_value);
		return $statement->fetch(PDO::FETCH_ASSOC);
	}
	
	
	
	/**
	 * @param array $rows          (optional)
	 * @param string $sorted_column (optional)
	 * @param int $asc           (optional)
	 * @return array
	 */
	public function sort_rows($rows=[], $sorted_column='', $asc=1) {
		$sorted_rows=[];
		if (count($rows)) {
			while ($row=array_shift($rows)) {
				$sorted_rows[$row[$sorted_column]]=$row;
			}
			if ($asc) {
				ksort($sorted_rows);
			}else {
				krsort($sorted_rows);
			}
		}
		return $sorted_rows;
	}
	
	
	
	/**
	 * @access public
	 * filter_string always start with WHERE
	 * @param string $table         (optional)
	 * @param string $filter_string (optional)
	 * @param array $filter_value  (optional)
	 * @return number
	 */
	public function count_row($table='', $filter_string='', $filter_value=[]) {
		if (strlen($filter_string)) {
			$query_string='SELECT COUNT(*) FROM `'. $table . '` ' . $filter_string;
		}else {
			$query_string='SELECT COUNT(*) FROM `'. $table . '`';
		}
		$this->get_connection();
		$statement=$this->mypdo->prepare($query_string);
		if (sizeof($filter_value) > 0) {
			$statement->execute((array)$filter_value);
		}else {
			$statement->execute();
		}
		$fetch=$statement->fetch(PDO::FETCH_NUM);
		return $fetch['0'];
	}
	
	
	
	
	/**
	 * @access public
	 * @param string $column        (optional)
	 * @param string $table         (optional)
	 * @param string $filter_string (optional)
	 * @param array $filter_value  (optional)
	 * @return int
	 */
	public function sum_col($column='', $table='', $filter_string='', $filter_value=[]) {
		if (strlen($filter_string)) {
			$query_string='SELECT SUM(`' . $column . '`) FROM `'. $table . '` ' . $filter_string;
		}else {
			$query_string='SELECT SUM(`' . $column . '`) FROM `'. $table . '`';
		}
		$this->get_connection();
		$statement=$this->mypdo->prepare($query_string);
		if (sizeof($filter_value)>0) {
			$statement->execute((array)$filter_value);
		}else {
			$statement->execute();
		}
		$fetch=$statement->fetch(PDO::FETCH_NUM);
		return $fetch['0'];
	}

	
	
	
	/**
	 * Run Raw SQL Query
	 * @access public
	 * @return rows
	 */
	public function select($query,$placeholders_values=[]){
		$this->get_connection();
		//prepare
		$statement = $this->mypdo->prepare($query);
		if (is_object($statement)) {
			//execute
			if (count($placeholders_values) > 0) {
				$statement->execute((array)$placeholders_values);
			}else {
				$statement->execute();
			}
			return $statement->fetchAll();
		}
	}
	
	
	
	
	
	/**
	 * @access public
	 * @param mixed $data
	 * @return mixed
	 */
	public function test_input($data) {
		if (is_array($data)==false) {
			$data = trim($data);
			$data = stripslashes($data);
			//$data = htmlspecialchars($data);
			return $data;
		}else {
			return $data;
		}
	}
	
	
	
	
	
	/**
	 * @access public
	 * @param mixed $data
	 * @return mixed
	 */
	 
	public function check_post_data($table, $post_data){
		$errors=[];
		
		//che function input
		if(!strlen($table)) $errors[] = 'TABLE name is required';
		if(!is_array($post_data)) $errors[] = 'POST Data is not an array';
		if(count($errors)){
			$this->print_errors($errors);
			return 0;
		}
		
		//get table info
		$info = $this->get_table_info($table);
		$fields = array_keys($info);
		
		
		//unset garbage
		foreach ($post_data as $key => $value) {
			if (in_array($key, $fields)) {
				continue;
			}else{
				unset ($post_data[$key]);
			}
		}
		
		
		//test_input & format value
		foreach ($post_data as $key => $value) {
			$post_data[$key]=$this->test_input($value);
			$type = $info[$key]['data_type'];
			switch($type){
				case 'date':
				$post_data[$key]=date_format(date_create($value), APP_DATE_FORMAT);
				break;
				case 'datetime':
				$post_data[$key]=date_format(date_create($value), APP_DATE_TIME_FORMAT);
				break;
				case 'time':
				$post_data[$key]=date_format(date_create($value), APP_TIME_FORMAT);
				break;
			}
		}
		
		
		//check varchar length
		foreach ($post_data as $key => $value) {
			if(($info[$key]['data_type']) == 'varchar'){
				if(strlen($value) > ($info[$key]['max_length'])){
					$errors[]='Error: value of ' . $key . ' in table '. $table . ' exceeds maximum length';
				}   
			}
		}
		
		
		//check is_nullable
		foreach ($post_data as $key => $value) {
			if(($info[$key]['is_nullable'] == 'NO') && !strlen($post_data[$key])){
				$errors[] = $key . ' in table ' . $table .' can not be empty';
			}
		}
		
		
		//print error
		if(count($errors)){
			$this->print_errors($errors);
			return 0;
		}
		
		return $post_data;

	}
	
	
	
	/**
	 *
	 * insert into table
	 * add/update missing value before input $post_data
	 * validate $post_data before input
	 * format $post_data before input
	 * access public
	 * @param string $table        (optional)
	 * @param array $post_data    (optional)
	 * @param array $session_data (optional)
	 * @param boolen $log          (optional)
	 * @return int
	 */
	public function insert($table='', $post_data=[], $session_data=[], $log=false) {
		$errors=[];
		
		//check post data
		$post_data = $this->check_post_data($table, $post_data);
		if(!is_array($post_data)){
			$errors[] = 'The request cannot be processed';
			$this->print_errors($errors);
			return 0;
		}
		
		//get table info
		$info = $this->get_table_info($table);
		$fields = array_keys($info);
			
			
		//session_data
		if (count($session_data)==0) {
			$session_data['id']=0;
			$session_data['category']='system';
		}
		
		//Add common Missing value to $post_data
		$post_data['creation_date']=date(APP_DATE_FORMAT);
		$post_data['creation_time']=date(APP_TIME_FORMAT);
		$post_data['creation_by']=$session_data['category'];
		$post_data['creator_id']=$session_data['id'];
		
		//initialize sql input
		$set_array=[];
		$set_values=[];
		foreach ($fields as $key) {
			if (array_key_exists($key , $post_data)) {
				$set_array[]=$key.'=:'.$key;
				$set_values[':'.$key]=$post_data[$key];
			}
		}
		//nothing to add
		if(count($set_array)==0) return 0;

		//INSERT Information
		$command='INSERT';
		$query_argument = [
			'command'  => $command,
			'select'  => [],
			'table'     => $table,
			'set_array'  => $set_array,
			'filter_string' => ''
		];
		$values_agrument = [
			'command'    => $command,
			'set_values'   => $set_values,
			'filter_values' => []
		];
		$query_string = $this->query_builder($query_argument);
		$values_string = $this->values_string($values_agrument);
		$log_values=[
			":filename"   	=>  basename(__FILE__, '.php'),
			":command"   	=> 	$command,
			":query_string" =>  $query_string,
			":values_string"=>  $values_string,
			":creator_id"  	=>  $session_data['id'],
			":creation_by"  =>  $session_data['category']
		];
		if ($log) {
			$this->operational_log($log_values);
		}
		$id = $this->run_query($query_string, $values_agrument);
		return $id;
	}

	
	
	
	/**
	 *
	 * @param string $table         (optional)
	 * @param array $post_data     (optional)
	 * @param string $filter_string (optional)
	 * @param array $filter_value  (optional)
	 * @param array $session_data  (optional)
	 * @param boolen $log           (optional)
	 * @return mixed
	 */
	public function update($table='', $post_data=[], $filter_string='', $filter_value=[], $session_data=[], $log=false) {
		$errors=[];
		
		//check post data
		$post_data = $this->check_post_data($table, $post_data);
		if(!is_array($post_data)){
			$errors[] = 'The request cannot be processed';
			$this->print_errors($errors);
			return 0;
		}
		
		//get table info
		$info = $this->get_table_info($table);
		$fields = array_keys($info);
			
		//session_data
		if (sizeof($session_data)==0) {
			$session_data['id']=0;
			$session_data['category']='system';
		}
		
		//Add common Missing value to $post_data
		$post_data['update_date']=date(APP_DATE_FORMAT);
		$post_data['update_time']=date(APP_TIME_FORMAT);
		$post_data['update_by']=$session_data['category'];
		$post_data['updater_id']=$session_data['id'];
			
		//checking gates
		if (strlen($filter_string)) {
			
			//initialize sql input
			$set_array=[];
			$set_values=[];
			foreach ($fields as $key) {
				if (array_key_exists($key , $post_data)) {
					$set_array[]=$key.'=:'.$key;
					$set_values[':'.$key]=$post_data[$key];
				}
			}
			
			//nothing to update
			if(count($set_array)==0) return 0;
		
			//UPDATE Information
			$command='UPDATE';
			$query_argument = [
				'command'  		=> $command,
				'select'  		=> [],
				'table'   		=> $table,
				'set_array'  	=> $set_array,
				'filter_string' => $filter_string
			];
			$values_agrument = [
				'command'    	=> $command,
				'set_values'   	=> $set_values,
				'filter_values' => $filter_value
			];
			$query_string = $this->query_builder($query_argument);
			$values_string = $this->values_string($values_agrument);
			$log_values=[
				":filename"   	=> basename(__FILE__, '.php'),
				":command"   	=> $command,
				":query_string" => $query_string,
				":values_string"=> $values_string,
				":creator_id"  	=> $session_data['id'],
				":creation_by"  => $session_data['category']
			];
			if ($log) {
				$this->operational_log($log_values);
			}
			$id = $this->run_query($query_string, $values_agrument);
			return $id;
		}else {
			return 0;
		}
	}




	
	/**
	 *
	 * @param string $table         (optional)
	 * @param string $filter_string (optional)
	 * @param array $filter_value  (optional)
	 * @param array $session_data  (optional)
	 * @param boolen $log           (optional)
	 * @return mixed
	 */
	public function delete_row($table='', $filter_string='', $filter_value=[], $session_data=[], $log=false) {
		//session_data
		if (sizeof($session_data)==0) {
			$session_data['id']=0;
			$session_data['category']='system';
		}
		
		/*DELETE Information*/
		$command='DELETE';
		$query_argument = [
			'command'    	=> $command,
			'select'     	=> [],
			'table'     	=> $table,
			'set_array'   	=> [],
			'filter_string' => $filter_string
		];
		$values_agrument = [
			'command'    	=> $command,
			'set_values'   	=> [],
			'filter_values' => $filter_value
		];
		$query_string = $this->query_builder($query_argument);
		$values_string = $this->values_string($values_agrument);
		$log_values=[
			":filename"   	=> basename(__FILE__, '.php'),
			":command"   	=> $command,
			":query_string" => $query_string,
			":values_string"=> $values_string,
			":creator_id"  	=> $session_data['id'],
			":creation_by"  => $session_data['category']
		];
		if ($log) {
			$this->operational_log($log_values);
		}
		$id = $this->run_query($query_string, $values_agrument);
		return $id;
	}
	
	
	
	
	
	/**
	 * TRUNCATE TABLE
	 * @access public
	 * @return void
	 */
	public function truncate($table){
		$this->get_connection();
		$query='TRUNCATE TABLE '. $table;
		//prepare
		$statement = $this->mypdo->prepare($query);
		if (is_object($statement)) {
				$statement->execute();
		}
	}
	
	
	
	
	
	
	/**
	 * 	Run SQL Command
	 * @access public
	 * @return void
	 */
	public function run_sql_command($command,$placeholders_values=[]){
		$this->get_connection();
		$statement = $this->mypdo->prepare($command);
		if (is_object($statement)) {
			//execute
			if (count($placeholders_values) > 0) {
				$statement->execute((array)$placeholders_values);
			}else {
				$statement->execute();
			}
			return $statement->fetchAll();
		}
	}
	
	
	
	
	
	
	/**
	 *
	 * @param string $attribute (optional)
	 * @return array
	 */
	public function get_tables($attribute='', $db_name = '') {
		//get table_schema
		if(strlen($db_name)){
			$table_schema = $db_name;
		}else{
			$this->set_db_params();
			$table_schema=$this->ndb_name;
		}
		//filter_string & filter_value
		if(strlen($attribute)){
			$filter_string = 'WHERE TABLE_SCHEMA=:TABLE_SCHEMA AND COLUMN_NAME=:COLUMN_NAME';
			$filter_value=[":TABLE_SCHEMA" => $table_schema, ":COLUMN_NAME" => $attribute];
		}else{
			$filter_string = 'WHERE TABLE_SCHEMA=:TABLE_SCHEMA';
			$filter_value=[":TABLE_SCHEMA" => $table_schema];
		}
		//get query_string
		$command='SELECT';
		$query_argument = [
			'command'     => $command,
			'select'      => ['TABLE_NAME'],
			'table'        => 'COLUMNS',
			'set_array'    => [],
			'filter_string' => $filter_string
		];
		$query_string = $this->query_builder($query_argument);
		//get get_infodb_connection
		$this->get_infodb_connection();
		$statement=$this->infopdo->prepare($query_string);
		$statement->execute((array)$filter_value);
		$rows=$statement->fetchAll();
		$tables=[];
		while ($row=array_shift($rows)) {
				$tables[]=$row['TABLE_NAME'];
		}
		return array_unique($tables);
	}

	
	
	
	######### 		  DBMS Stop Here 			#####
	
	
	################## memcached server Start #############
	
	/**
	 * get connection to memcached server
	 * @access public
	 * @return void
	 */
	public $mycache = null;
	
	



	/**
	 * start-memcached and SET mycache
	 * @access public
	 * @raddb
	 */
	public function mycache_connect() {
		if ($this->mycache === null) {
			$this->mycache = new Memcached();
			$this->mycache->addServer('127.0.0.1', 11211);
		}
	}

	
	
	/**
	 * cache status
	 * @access public
	 */
	public function cache_stats() {
		$this->mycache_connect();
		return $this->mycache->getStats();
	}




	/**
	 * get memcached key
	 * @access public
	 * @param string $table       (optional)
	 * @return string
	 */
	public function get_cache_key($table='') {
		if (strlen($table)) {
			return $table. '_' . session_id();
		}
	}


	
	/**
	 * @access public
	 * @param string $cache_key
	 * @param mixed $data
	 * @return mixed
	 */
	public function add_to_memcache($cache_key,$data) {
		$this->mycache_connect();
		$this->mycache->delete($cache_key);
		return $this->mycache->add($cache_key, $data, 300);
	}
	
	
	
	/**
	 * @access public
	 * @param string $cache_key
	 * @return mixed
	 */
	public function delete_from_memcache($cache_key) {
		$this->mycache_connect();
		$this->mycache->delete($cache_key);
		return 1;
	}
	
	
	
	/**
	 * @access public
	 * @param string $cache_key
	 * @return mixed
	 */
	public function get_from_memcache($cache_key) {
		$this->mycache_connect();
		return $this->mycache->get($cache_key);
	}
	

	/**
	 *
	 * @param string $table         (optional)
	 * @param string $filter_string (optional)
	 * @param array $filter_value  (optional)
	 * @param int $sort          (optional)
	 * @param string $sorted_column (optional)
	 * @param int $asc           (optional)
	 * @return array
	 */
	public function cache_rows($table='', $filter_string='', $filter_value=[], $sort=0, $sorted_column='', $asc=1) {
		//process value
		$rows=$this->rows($table, $filter_string, $filter_value);
		if ($sort) {
			$rows=$this->sort_rows($rows, $sorted_column, $asc);
		}
		//connect to memcached
		$cache_key=$this->get_cache_key($table);
		$this->mycache_connect();
		//remove old cache
		$cache=$this->mycache->get($cache_key);
		if($cache){
			$this->purge_cached_rows($table);
		}
		//add to cache
		$this->mycache->add($cache_key, $rows, 300);
		return $rows;
	}




	/**
	 *
	 * @param string $table         (optional)
	 * @param string $filter_string (optional)
	 * @param array $filter_value  (optional)
	 * @param boolen $sort          (optional)
	 * @param string $sorted_column (optional)
	 * @param boolen $asc           (optional)
	 * @return mixed
	 */
	public function get_cached_rows($table='', $filter_string='', $filter_value=[], $sort=0, $sorted_column='', $asc=1) {
		$cache_key=$this->get_cache_key($table);
		//connect to memcached
		$this->mycache_connect();
		$rows=$this->mycache->get($cache_key);
		if ($rows) {
			return $rows;
		}else {
			//process value
			$rows=$this->rows($table, $filter_string, $filter_value);
			if ($sort) {
				$rows=$this->sort_rows($rows, $sorted_column, $asc);
			}
			//store to memcached
			$this->mycache->add($cache_key, $rows, 300);
			return $rows;
		}
	}



	/**
	 * @param string $table       (optional)
	 * @param string $update_key
	 * @param array $updated_row
	 * @return mixed
	 */
	public function update_cached_row($table='', $update_key, $updated_row=[]) {
		$cache_key=$this->get_cache_key($table);
		//connect to memcached
		$this->mycache_connect();
		$rows=$this->mycache->get($cache_key);
		if ($rows) {
			//update row
			if (count($updated_row)) {
				$rows[$update_key]=$updated_row;
			}else {
				unset($rows[$update_key]);
			}
			$this->mycache->replace($cache_key, $rows, 300);
			return $this->mycache->getResultMessage();
		}else {
			return $this->mycache->getResultMessage();
		}
	}



	/**
	 *
	 * @param string $table
	 * @param int $operator_id
	 * @return mixed
	 */
	public function purge_cached_rows($table) {
		$cache_key = $this->get_cache_key($table);
		//connect to memcached
		$this->mycache_connect();
		$this->mycache->delete($cache_key);
		return $this->mycache->getResultMessage();
	}



	################## memcached server stop #############
	
	
	#########  NOT DBMS Methods Start Here   ########
	
	/**
	 *
	 * @param array $errors (optional)
	 * @return null
	 * @ access public
	 */
	public function print_errors($errors=[]){
		foreach ($errors as $error){
			$alert  = '';
			$alert .= '<div class="alert alert-danger">';
			$alert .= $error;
			$alert .= '</div>';
			echo $alert;
		}
	}
	
	
	/**
	 *
	 * @param string $message (optional)
	 * @return null
	 * @ access public
	 */
	public function print_message($message='', $require_close = 0){
		$m  = '';
		$m .= '<div class="alert alert-info">';
		$m .= $message;
		$m .= '</div>';
		if($require_close){
		$m .= '<div id="close_button"></div>';
		}
		echo $m;
	}
	
	
	/**
	 *
	 * @param string $message (optional)
	 * @return null
	 * @ access public
	 */
	 
	public function print_messages($messages=[]){
		foreach ($messages as $message){
			$alert  = '';
			$alert .= '<div class="alert alert-info">';
			$alert .= $message;
			$alert .= '</div>';
			echo $alert;
		}
	}
	
	
	/**
	 *
	 * @param string $url
	 */
	public function redirect($url) {
		if (!headers_sent()) {
			header('Location: ' . $url);
			die;
		} else {
			echo '<script type="text/javascript">';
			echo 'window.location.href="' . $url . '";';
			echo '</script>';
			echo '<noscript>';
			echo '<meta http-equiv="refresh" content="0;url=' . $url . '" />';
			echo '</noscript>';
			die;
		}
	}
	
	
	
	
	/**
	 *
	 * @return password
	 */
	public function randomPassword() {
		$alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
		$pass = array(); //remember to declare $pass as an array
		$alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
		for ($i = 0; $i < 10; $i++) {
			$n = rand(0, $alphaLength);
			$pass[] = $alphabet[$n];
		}
		return implode($pass); //turn the array into a string
	}


	
	
	
	/**
	 * method to encrypt or decrypt a plain text string
	 * initialization vector(IV) has to be the same when encrypting and decrypting
	 * @param string  $action : can be 'encrypt' or 'decrypt'
	 * @param mixed   $value  : value to encrypt or decrypt
	 * @return mixed value
	 */
	public function encrypt_decrypt($action, $value) {
		$output = false;
		$cipher_method = "AES-256-CBC";
		//more methods @openssl_get_cipher_methods()
		$secret_key = APP_KEY;
		$secret_iv =  APP_IV;
		$key = hash('sha256', $secret_key);
		$iv_length=openssl_cipher_iv_length($cipher_method);
		$iv = substr(hash('sha256', $secret_iv), 0, $iv_length);
		if ( $action == 'encrypt' ) {
			$value = json_encode($value);
			$output = openssl_encrypt($value, $cipher_method, $key, 0, $iv);
			$output = base64_encode($output);
		} else if ( $action == 'decrypt' ) {
			$output = openssl_decrypt(base64_decode($value), $cipher_method, $key, 0, $iv);
			$output = json_decode($output, true);
		}
		return $output;
	}


	

	/**
	 *
	 * @param string $mobile_number
	 * @return string
	 */
	public function validate_mobile($mobile_number) {
		$mobile=substr(trim($mobile_number), -10, 10);
		$len=strlen($mobile);
		if ($len==10) {
			//check operator code
			$operators=['11', '12', '13', '14', '15', '16', '17', '18', '19'];
			$operator=substr($mobile, -10, 2);
			if (in_array($operator, $operators)) {
				//check all are digits
				$digits=str_split($mobile);
				//allowed digits
				$ad=['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
				for ($i=0;$i<$len; $i++) {
					if (!in_array($digits[$i], $ad)) {
						return 0;
					}
				}
			}else {
				return 0;
			}
			return '0'.$mobile;
		}else {
			return 0;
		}
	}

	
	
	
	/**
	* @return variable name from string
	* @access public
	* @parameter string
	*/
	public function get_var_name($string){
	$string=trim($string);
	$allowed_chars=['_', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
	
	if(strlen($string)){
		$var='';
		$chars=str_split($string);
		$len=count($chars);
		for($i=0; $i<$len; $i++){
			if (in_array($chars[$i], $allowed_chars)) {
				$var.=$chars[$i];
			}else{
				$var.='_';
			}
		}
		return $var;
	}else{
		return null;
	}
	}
	
	
	
	/**
	* @ remove illegal characters from string
	* @access public
	* @parameter string
	*/
	public function remove_illegal_char($string){
	$string=trim($string);
	$allowed_chars=['-', '_', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
	
	if(strlen($string)){
		$var='';
		$chars=str_split($string);
		$len=count($chars);
		for($i=0; $i<$len; $i++){
			if (in_array($chars[$i], $allowed_chars)) {
				$var.=$chars[$i];
			}else{
				$var.='_';
			}
		}
		return $var;
	}else{
		return null;
	}
	}
	
	
	
	

	/**
	 *
	 * @return boolen
	 */
	public function is_mobile() {
		$detect = new Mobile_Detect;
		return $detect->isMobile();
	}



	/**
	 *
	 * @param int $seconds
	 * @return string
	 */
	public function seconds_to_hour_minute_second($seconds) {
		$h=0;
		$m=0;
		$s=round($seconds);
		while ($s>60) {
			$s=$s-60;
			$m=$m+1;
		}
		while ($m>60) {
			$m=$m-60;
			$h=$h+1;
		}
		$value=$h.' Hour '.$m.' Minute '.$s.' Second ';
		return $value;
	}
	
	
	/**
	 *
	 * @return array
	 */
	public function get_start_and_stop_time_of_last_month() {
		$this_month = round(date('m'));
		$this_year = round(date('Y'));
		if ($this_month == 1) {
			$past_month = 12;
			$past_year = $this_year - 1;
		} else {
			$past_month = $this_month - 1;
			$past_year = $this_year;
		}
		$past_month_length = round(date_format(date_create($past_year . '-' . $past_month . '-' . '1'), 't'));
		$start_time=date_format(date_create($past_year . '-' . $past_month . '-' . '01'), 'Y-m-01 00:00:00');
		$stop_time=date_format(date_create($past_year . '-' . $past_month . '-' . $past_month_length), 'Y-m-d 23:59:59');
		return [$start_time, $stop_time];
	}
	
	
	
	
	/**
	 *
	 * @return string
	 */
	public function previous_month() {
		$this_month = round(date('m'));
		$this_year = round(date('Y'));
		if ($this_month == 1) {
			$past_month = 12;
			$past_year = $this_year - 1;
		} else {
			$past_month = $this_month - 1;
			$past_year = $this_year;
		}
		$previous_month=date_format(date_create($past_year . '-' . $past_month . '-' . '1'), 'F-Y');
		return $previous_month;
	}




	/**
	 *
	 * @return string
	 */
	public function this_month() {
		$this_month = round(date('m'));
		$this_year = round(date('Y'));
		$this_month=date_format(date_create($this_year . '-' . $this_month . '-' . '1'), 'F-Y');
		return $this_month;
	}




	/**********@@@@@@ File upload @@@@@@**********/
	
	
	public $uploader = null;



	/**
	 * initialize uploader
	 * @param string $file
	 */
	public function initialize_uploader($file) {
		//unset previous session
		if (is_object($this->uploader)) {
			$this->uploader = null;
		}
		//initialize uploader object
		if (!is_object($this->uploader)) {
			//initialize object
			$this->uploader = new upload($file);
		}
	}




	/**
	 * file upload
	 * @param string $file      (optional)
	 * @param string $prefix
	 * @param array $file_type (optional)
	 * @param string $file_size (optional)
	 * @param int $user_id
	 * @param int $image_x   (optional)
	 * @param boolen $resize    (optional)
	 * @return mixed
	 */
	public function upload_file($file=array(), $prefix, $file_type=array(), $file_size='512K', $user_id, $image_x=150, $resize=true) {
		//$file_type=array('image/*','application/pdf');
		$upload_dir = $_SERVER['DOCUMENT_ROOT'].'/uploads/';
		$result['error']=$result['file_name']='';
		$this->initialize_uploader($file);
		$this->uploader->upload($file);
		if ($this->uploader->uploaded) {
			$this->uploader->file_name_body_pre =$prefix;
			$this->uploader->file_new_name_body = $user_id.'-'.rand();
			$this->uploader->allowed =$file_type;
			$this->uploader->file_max_size = $file_size;
			$this->uploader->image_x=$image_x;
			$this->uploader->image_ratio_y=true;
			$this->uploader->image_resize = $resize;
			$this->uploader->image_convert = 'jpg';
			$this->uploader->file_overwrite = true;
			$this->uploader->Process($upload_dir);
			if ($this->uploader->processed) {
				$file_name=$this->uploader->file_dst_name;
				$this->uploader->Clean();
				$result['file_name']=$file_name;
			}else {
				$result['error']=$this->uploader->error;
			}
		}else {
			$result['error']==$this->uploader->error;
		}
		return $result;
	}
	
	/**
	 * return logoMini
	 * @param array $session_data (optional)
	 * @return mixed
	 * @override by app calss
	 */
	 
	public function logoMini($session_data=[]){
		return APP_LOGO_MINI;
	}
	
	
	
	/**
	 * return logoLg
	 * @param array $session_data (optional)
	 * @return mixed
	 * @override by app calss
	 */
	 
	public function logoLg($session_data=[]){
		return APP_LOGO_LG;
	}

/*class*/}