<?php
if (isset($_POST['table'])) {
	include 'constants.php';
	include 'class.app.db.config.php';
	include 'class.base.php';
	$dbo = new base();
	$table = trim($_POST['table']);
	$column = trim($_POST['column']);
	$column_value = trim($_POST['value']);
	if (strlen($column_value)) {
		if ($dbo->count_row($table,'WHERE '. $column .'=:'. $column, [ ":". $column => $column_value])) {
			echo '<br/>' . '<span class=\'alert alert-danger\'>Duplicate Detected</span>';
		} else {
			echo '<br/>'. '<span class=\'alert alert-success\'>Available</span>';
		}
	}
}
?>
