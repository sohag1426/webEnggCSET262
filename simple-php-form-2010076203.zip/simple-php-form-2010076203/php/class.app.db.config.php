<?php
class app_db_config {
	const  app_db_host = 'localhost';
	const  app_db_user = 'root';
	const  app_db_pass = '';
	const  app_db_name = 'simple';
	const  app_db_port = 3306;
	const  app_db_char = 'utf8';
}
?>
