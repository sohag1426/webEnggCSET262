<?php
define("APP_KEY", 'lvfcDj3m2Keu');
define("APP_IV", 'OzddKOrjjxSt');
define("APP_DATE_FORMAT", 'Y-m-d');
define("APP_TIME_FORMAT", 'H:i:s');
define("APP_DATE_TIME_FORMAT", 'Y-m-d H:i:s');
define("APP_MONTH_FORMAT", 'M-Y');
define("APP_DAY_FORMAT", 'j');
