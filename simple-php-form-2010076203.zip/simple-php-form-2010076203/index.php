<?php
include 'php/session.php';
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <title>Bootstrap Form</title>
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/app.css">
</head>
<body class="bg-light">
<!--navigation-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="collapse navbar-collapse">
<ul class="navbar-nav mr-auto">
  <li class="nav-item">
	<a class="nav-link" href="index.php">Home</a>
  </li>
  <li class="nav-item">
	<a class="nav-link"  href="admin.php">Admin</a>
  </li>
</ul>
</div>
  <form class="form-inline" method="post" action="php/session.php">
    <button class="btn btn-outline-danger my-2 my-sm-0" type="submit" name="logout" >Logout</button>
  </form>
</nav>
<!--/navigation-->
<div class="container">
<div class="row">
<div class="col-xs-12">
<h1>Job Application of X Company</h1>
<h4>Wish to play a role in building the future?</h4>
<a href="signup.php"><h4>Apply Now</h4></a>
<a href="signin.php"><h4>Show Status</h4><a>
</div>
</div>
</div>
<!-- Bootstrap core JavaScript -->
  <script src="jquery/jquery-3.4.1.min.js"></script>
  <script src="bootstrap/js/bootstrap.js"></script>
</body>
</html>