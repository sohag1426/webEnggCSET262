<?php
include 'php/session.php';
require 'php/class.upload.php';
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <title>Bootstrap Form</title>
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/app.css">
</head>
<body class="bg-light">
<!--navigation-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="collapse navbar-collapse">
<ul class="navbar-nav mr-auto">
  <li class="nav-item">
	<a class="nav-link" href="index.php">Home</a>
  </li>
  <li class="nav-item">
	<a class="nav-link"  href="admin.php">Admin</a>
  </li>
</ul>
</div>
  <form class="form-inline" method="post" action="php/session.php">
    <button class="btn btn-outline-danger my-2 my-sm-0" type="submit" name="logout" >Logout</button>
  </form>
</nav>
<!--/navigation-->
<div class="container">
<div class="row">
<div class="col-xs-12">

<?php 

if($_SERVER["REQUEST_METHOD"] == "POST") {
	
	/*reformating_*/
	$_POST['date_of_birth'] = date_format(date_create($_POST['d_year'].'-'.$_POST['d_month'].'-'.$_POST['d_day']),'Y-m-d');
	if(isset($_POST['division'])){
		$_POST['division_of_interest'] = json_encode($_POST['division'], JSON_FORCE_OBJECT);
	}
	/*_reformating*/
	
	//upload
	if(isset($_FILES['cv'])){
		$foo = new Upload($_FILES['cv']); 
		if ($foo->uploaded) {
		   $foo->process('uploads/');
		   if ($foo->processed) {
			 $_POST['cv'] = $foo->file_dst_name;
		   } else {
			 echo 'error : ' . $foo->error;
		   }
		}
	}	
	
	/*validation_*/
	#username
	 $count = $dbo->count_row('users','WHERE username=:username',[":username" => trim($_POST['username'])]);
	 if($count){
		 $dbo->print_errors($errors=['Duplicate username']);
		 exit;
	}
	/*_validation*/
	
	
	$id = $dbo->insert('users',$_POST, $session_data=[], $log=false);
	
	if($id){
		$dbo->print_messages($messages=['Application has been submited successfully']);
		$dbo->print_messages($messages=['<a href="signin.php"><h4>Show Status</h4><a>']);
	}
}
?>



<?php if(isset($_POST['submit']) == false){ ?>
<h1>Job Application of X Company</h1>
<p><span class="text-danger">* required field.</span></p>

<form id="sid03" enctype="multipart/form-data" action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"  method="post">
 <!--username-->
  <div class="form-group">
    <label for="username"><span class="text-danger">*</span><b>username</b></label>
    <input type="text" maxlength="64" class="form-control" id="username" name="username" required="" onBlur="duplicate_check('duplicate_check','users','username',this.value)">
	<div id='duplicate_check'></div>
  </div>
  <!--/username-->
  <!--password-->
  <div class="form-group">
    <label for="password"><span class="text-danger">*</span><b>Password</b></label>
    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required="">
  </div>
  <!--password-->
  <!--Name-->
	<div class="form-group">
   <div class="row">
  	<label for="first_name">&nbsp;&nbsp;&nbsp;<span class="text-danger">*</span><b>Name</b></label>
  </div>
  <div class="row">
    <div class="col">
      <input type="text" maxlength="64" class="form-control" id="first_name" name="first_name" aria-describedby="first_name_help" required="">
      <small id="first_name_help" class="form-text text-muted">First</small>
    </div>
    <div class="col">
      <input type="text" maxlength="64" class="form-control"  id="last_name" name="last_name" aria-describedby="last_name_help" required="">
      <small id="last_name_help" class="form-text text-muted">Last</small>
    </div>
  </div>
</div>
<!--/Name-->

<!--Email-->
<br>
  <div class="form-group">
    <label for="email"><span class="text-danger">*</span><b>Email address</b></label>
    <input type="email" class="form-control" id="email" name="email" required="">
  </div>
<!--/Email-->

<!--Phone-->
<br>
  <div class="form-group">
    <label for="phone"><span class="text-danger">*</span><b>Phone</b></label>
    <input type="number" class="form-control" id="phone" name="phone" required="">
  </div>
<!--/Phone-->

<!--Web Site-->
<br>
  <div class="form-group">
    <label for="web_site"><b>Web Site(Optional)</b></label>
    <input type="text" class="form-control" id="web_site" name="web_site" placeholder="http://">
  </div>
<!--/Web Site-->

  	
<!--Date of Birth-->
<br>
	<div class="form-group">
   <div class="row">
  	<label for="d_month">&nbsp;&nbsp;&nbsp;<span class="text-danger">*</span><b>Date of Birth</b></label>
  </div>
  <div class="row">
    <div class="col">
      <input type="text" class="form-control" id="d_month" name="d_month" aria-describedby="d_month_help" required="">
      <small id="d_month_help" class="form-text text-muted">MM</small>
    </div>
    <span>/</span>
    <div class="col">
      <input type="text" class="form-control"  id="d_day" name="d_day" aria-describedby="d_day_help" required="">
      <small id="d_day_help" class="form-text text-muted">DD</small>
    </div>
    <span>/</span>
    <div class="col">
      <input type="text" class="form-control"  id="d_year" name="d_year" aria-describedby="d_year_help" required="">
      <small id="d_year_help" class="form-text text-muted">YYYY</small>
    </div>
  </div>
</div>
<!--/Date of Birth-->

<!--Street Address-->
<br>
 <div class="form-group">
    <label for="address"><b>Address</b></label>
    <input type="text" class="form-control" id="address" name="street_address" aria-describedby="street_address_help" required="">
    <small id="street_address_help" class="form-text text-muted"><span class="text-danger">*</span>Street Address</small>
  </div>
<!--/Street Address-->

<!--Address Line 2-->
 <div class="form-group">
    <input type="text" class="form-control" name="address_line_2" aria-describedby="address_line_2_help" >
    <small id="address_line_2_help" class="form-text text-muted">Address Line 2</small>
  </div>
<!--/Address Line 2-->


 <div class="row">
 	<!--City-->
    <div class="col">
    <input type="text" class="form-control" name="city" aria-describedby="city_help" >
    <small id="city_help" class="form-text text-muted">City</small>
  </div>
  <!--/City-->
  <!--State/province/Region-->
    <div class="col">
    <input type="text" class="form-control" name="state" aria-describedby="state_help" >
    <small id="state_help" class="form-text text-muted">State/province/Region</small>
  </div>
  <!--/State/province/Region-->
</div>

<div class="row">
 	<!--Postal/Zip Code-->
    <div class="col">
    <input type="number" class="form-control" name="postal" aria-describedby="postal_help" required="">
    <small id="postal_help" class="form-text text-muted"><span class="text-danger">*</span>Postal/Zip Code</small>
  </div>
  <!--/Postal/Zip Code-->
  <!--Country-->
    <div class="col">
    	<select class="form-control" name="country" aria-describedby="country_help" required="">
  			<option value=""></option>
  			<option value="Bangladesh">Bangladesh</option>
		</select>
	<small id="country_help" class="form-text text-muted"><span class="text-danger">*</span>Country</small>
  </div>
  <!--/Country-->
</div>

<!--Sex-->
<br>
<p><b>Sex</b></p>
<div class="form-check">
  <input class="form-check-input" type="radio" name="sex" id="male_option" value="male">
  <label class="form-check-label" for="male_option">
   Male
  </label>
</div>
<div class="form-check">
  <input class="form-check-input" type="radio" name="sex" id="female_option" value="female">
  <label class="form-check-label" for="female_option">
   Female
  </label>
</div>
<!--/Sex-->
<!--Bio-->
<br>
<div class="form-group">
    <label for="bio"><b>Bio</b></label>
    <textarea class="form-control" id="bio" name="bio" rows="3"></textarea>
  </div>
<!--/Bio-->

<!--Division of Interest-->
<br>
<p><b>Division of Interest</b></p>
<div class="form-check">
  <input class="form-check-input" type="checkbox" name="division[]" value="HR Division" id="hr">
  <label class="form-check-label" for="hr">
   HR Division
  </label>
</div>

<div class="form-check">
  <input class="form-check-input" type="checkbox" name="division[]" value="IT Division" id="it">
  <label class="form-check-label" for="it">
   IT Division
  </label>
</div>

<div class="form-check">
  <input class="form-check-input" type="checkbox" name="division[]" value="Marketing Division" id="marketing">
  <label class="form-check-label" for="marketing">
   Marketing Division
  </label>
</div>

<div class="form-check">
  <input class="form-check-input" type="checkbox" name="division[]" value="Other" id="other">
  <label class="form-check-label" for="other">
   Other
  </label>
</div>
<!--/Division of Interest-->

<!--Expected Salary-->
	<br>
      <label for="salary"><span class="text-danger">*</span><b>Expected Salary</b></label>
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">TK</div>
        </div>
        <input type="text" class="form-control" id="salary" name="salary" required="">
      </div>
<!--/Expected Salary-->
<!--Latest Degree-->
<br>
<label  for="degree"><span class="text-danger">*</span><b>Latest Degree</b></label>
  <select class="custom-select my-1 mr-sm-2" id="degree" name="latest_degree" required="">
    <option selected>Choose...</option>
    <option value="bsc">B.Sc</option>
    <option value="msc">M.Sc</option>
    <option value="hsc">HSC</option>
  </select>
<!--Latest Degree-->

<!--Years of Experience-->
<br>
  <div class="form-group">
    <label for="experience"><span class="text-danger">*</span><b>Year(s) of Experience</b></label>
    <input type="number" class="form-control" id="experience" name="experience" required="">
  </div>
<!--/Years of Experience-->

<!--Current Designation-->
<br>
  <div class="form-group">
    <label for="designation"><span class="text-danger">*</span><b>Name of Current Designation</b></label>
    <input type="text" class="form-control" id="designation" name="designation" required="">
  </div>
<!--/Current Designation-->

<!--Upload CV-->
<br>
 <div class="form-group">
    <label for="cv"><b>Upload CV</b></label>
    <input type="file" class="form-control-file" id="cv" name="cv">
  </div>
<!--/Upload CV-->

<br>
<button class="btn btn-primary" type="submit" name="submit">Submit</button>
</form>

<?php } ?>

</div>
</div>
</div>
<!-- Bootstrap core JavaScript -->
  <script src="jquery/jquery-3.4.1.min.js"></script>
  <script src="bootstrap/js/bootstrap.js"></script>
  <script type="text/javascript" src="jquery-validation/dist/jquery.validate.js"></script>
  <script>
    $("#sid03").validate({
     onkeyup: true,
      rules: {
	    phone: {
	      required: true,
	      minlength: 11,
	      maxlength: 11
	    },
		d_month: {
	      required: true,
	      range: [01, 12]
	    },
		d_day: {
	      required: true,
	      range: [01, 31]
	    },
		d_year: {
	      required: true,
	      range: [1970, 2000]
	    },
		web_site: {
	      url: true
	    },
		experience: {
			range: [1, 20]
		},
		salary: {
			range: [25, 100000]
		}
	  },
	  messages: {
	    first_name: {
	      required: "Valid First Name is required"
	    },
	    last_name: {
	    	required: "Valid Last Name is required"
	    }
	  }
	});
	
	function duplicate_check(id = '', table = '', column = '', value = '') {
    let post_value = {
        table: table,
        column: column,
        value: value
    };
    $.ajax({
        url: "php/duplicate-check.php",
        data: post_value,
        method: "POST",
        success: function(data) {
            $("#" + id).html(data)
        },
    })
	}

    </script>

</body>
</html>