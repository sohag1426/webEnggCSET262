SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

CREATE DATABASE IF NOT EXISTS `simple` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `simple`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` text NOT NULL,
  `first_name` varchar(64) NOT NULL,
  `last_name` varchar(64) NOT NULL,
  `email` text NOT NULL,
  `phone` varchar(14) NOT NULL,
  `web_site` text,
  `date_of_birth` date DEFAULT NULL,
  `street_address` text NOT NULL,
  `address_line_2` text,
  `city` text,
  `state` text,
  `postal` text,
  `country` text,
  `sex` enum('male','female') DEFAULT NULL,
  `bio` text,
  `division_of_interest` text,
  `salary` varchar(64) DEFAULT NULL,
  `latest_degree` varchar(64) DEFAULT NULL,
  `experience` varchar(64) DEFAULT NULL,
  `designation` text,
  `cv` text,
  `is_admin` bit(1) NOT NULL DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
