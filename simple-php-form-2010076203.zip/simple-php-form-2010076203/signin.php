<?php
include 'php/session.php';
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <title>Bootstrap Form</title>
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/app.css">
</head>
<body class="bg-light">
<!--navigation-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="collapse navbar-collapse">
<ul class="navbar-nav mr-auto">
  <li class="nav-item">
	<a class="nav-link" href="index.php">Home</a>
  </li>
  <li class="nav-item">
	<a class="nav-link"  href="admin.php">Admin</a>
  </li>
</ul>
</div>
  <form class="form-inline" method="post" action="php/session.php">
    <button class="btn btn-outline-danger my-2 my-sm-0" type="submit" name="logout" >Logout</button>
  </form>
</nav>
<!--/navigation-->
<div class="container">
<div class="row">
<div class="col-xs-12">

<?php
if($_SERVER["REQUEST_METHOD"] == "POST") {
	$username = $dbo->test_input($_POST['username']);
	$password = $dbo->test_input($_POST['password']);
	$count =$dbo->count_row('users','WHERE `username`=:username',[":username" => $username]);
	if ($count == 1) {
		$row=$dbo->row('users','WHERE `username`=:username',[":username" => $username]);
		if((strcmp($row['username'], $username)==0) && (strcmp($row['password'], $password)==0)){
			$session_data = $row;
			//Encrypted session_data
			$_SESSION['session_data'] = $dbo->encrypt_decrypt('encrypt',$session_data);
			if($session_data['is_admin']){
				$dbo->redirect('admin.php');
			}	
		} else {
			$dbo->print_errors($errors=['Username or Password is Wrong']);
		}
	}
}
?>
<?php if(count($session_data)==0){ ?>
<h1>Sign In</h1>
<p><span class="text-danger">* required field.</span></p>
<form id="sid03" action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"  method="post">
 <!--username-->
  <div class="form-group">
    <label for="username"><span class="text-danger">*</span><b>username</b></label>
    <input type="text" maxlength="64" class="form-control" id="username" name="username" required="">
  </div>
  <!--/username-->
  <!--password-->
  <div class="form-group">
    <label for="password"><span class="text-danger">*</span><b>Password</b></label>
    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required="">
  </div>
  <!--password-->
  <br>
<button class="btn btn-primary" type="submit" name="submit">Sign In</button>
</form>
<?php }else{
		if($session_data['is_admin']){
			$dbo->redirect('admin.php');
		}
	?>
	<br>
	<br>
<ul class="list-group">
  <li class="list-group-item"><b>username: </b> <?= $session_data['username'] ?> </li>
  <li class="list-group-item"><b>Name: </b> <?= $session_data['first_name'] . ' ' . $session_data['last_name'] ?></li>
  <li class="list-group-item"><b>Email address: </b> <?= $session_data['email'] ?> </li>
  <li class="list-group-item"><b>Phone: </b> <?= $session_data['phone'] ?> </li>
  <li class="list-group-item"><b>Web Site: </b> <?= $session_data['web_site'] ?> </li>
  <li class="list-group-item"><b>Date of Birth: </b> <?= $session_data['date_of_birth'] ?> </li>
  <li class="list-group-item"><b>Address: </b> <?= '<br>' . $session_data['street_address'] . '<br>' . $session_data['address_line_2'] . '<br>' . $session_data['city'] . ',' . $session_data['state'] . '-' . $session_data['postal'] . '<br>' . $session_data['country'] ?> </li>
  <li class="list-group-item"><b>Sex: </b> <?= $session_data['sex'] ?> </li>
  <li class="list-group-item"><b>Bio: </b> <?= $session_data['bio'] ?> </li>
  <li class="list-group-item"><b>Division of Interest: </b><br> 
  <?php
	$interests = json_decode($session_data['division_of_interest'], true);
	foreach ($interests as $i){
		echo $i . '<br>';
	}
  ?>
  </li>
  <li class="list-group-item"><b>Expected Salary: </b> <?= $session_data['salary'] . ' TK' ?> </li>
  <li class="list-group-item"><b>Latest Degree: </b> <?= $session_data['latest_degree'] ?> </li>
  <li class="list-group-item"><b>Year(s) of Experience: </b> <?= $session_data['experience'] . ' Year' ?> </li>
  <li class="list-group-item"><b>Name of Current Designation: </b> <?= $session_data['designation'] ?> </li>
  <li class="list-group-item"><b>CV: </b>
  <?php if(strlen($session_data['cv'])) { ?>
   <a href="<?php echo 'uploads/'. $session_data['cv']; ?>">Download</a>
  <?php } ?>
  </li>
</ul>
  <br>
	<br>
<?php } ?>

</div>
</div>
</div>
<!-- Bootstrap core JavaScript -->
  <script src="jquery/jquery-3.4.1.min.js"></script>
  <script src="bootstrap/js/bootstrap.js"></script>
</body>
</html>